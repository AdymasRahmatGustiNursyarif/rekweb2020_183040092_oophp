<?php

class Mobil {
	public $nama,
	public $merk,
	public $warna,
	public $kecepatanMaksimal,
	public $jumlahPenumpang;

	public function tambahKecepatan() {


	}


	public function kurangiKecepatan() {


	}


    public function gantiTransmisi() {
    
    }
}